package de.fuberlin.wiwiss.d2rq.vocab;
/**
 * Specifies the template variable prefix URI for the metadata extension
 * 
 * @author Hannes Muehleisen (hannes@muehleisen.org)
 */

public class META {

	public static final String NS = "http://www4.wiwiss.fu-berlin.de/bizer/d2r-server/metadata#";
}
